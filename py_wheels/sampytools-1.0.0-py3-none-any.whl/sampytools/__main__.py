def main():
    print("I am python utilities developed by samrullo")

if __name__=="__main__":
    main()